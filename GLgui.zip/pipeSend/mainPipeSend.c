#include <stdlib.h>
#include <stdio.h>
#include <Windows.h>
#include <time.h>
#include <stdbool.h>


#define PIPE_BUFFER_SIZE 512

OVERLAPPED connectOverlap;

struct point {
	float x;
	float y;
} point;

#define N_HP_VALS 2000
#define N_CHAR_TITLE 1024
struct pipeData{
	unsigned int combo;
	float acc;
	struct point hp[N_HP_VALS];
	char songName[N_CHAR_TITLE];
};

unsigned long getMS(){
	time_t msec = time(NULL) * 1000;


	return msec;
}

int main(int argc, char *argv[]) {
	size_t nBytesTransferred;
	//bool waitingForRequest = false;
	bool sendResponse = false;
	bool sentResponse = false;
	unsigned long count = 0;

	unsigned long progTime = getMS();

	char sendString[] = "Test string\0";

	unsigned long currentTime;
	char data[2];

	struct pipeData dSend;

	// Initialize data structure to send
	dSend.acc = 100.0f;
	dSend.combo = 5;
	strcpy(dSend.songName, "ATC - Around the World\0");
	for (size_t i = 0; i < N_HP_VALS; i++){
		dSend.hp[i].x = (i - 1000.0f) / 100.0f;
		dSend.hp[i].y = 0;
	}

	connectOverlap.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	connectOverlap.Offset = 0;
	connectOverlap.OffsetHigh = 0;
	fprintf(stdout, "Server started\n");

	//HANDLE pipe = CreateNamedPipe(
	//	"\\\\.\\pipe\\osuPipe",
	//	PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
	//	PIPE_WAIT,
	//	PIPE_UNLIMITED_INSTANCES,
	//	PIPE_BUFFER_SIZE,
	//	PIPE_BUFFER_SIZE,
	//	120 * 1000,
	//	NULL);
	HANDLE pipe = CreateFile(
		L"\\\\.\\pipe\\osuPipe",   // pipe name 
		GENERIC_WRITE,
		FILE_SHARE_WRITE,              // no sharing 
		NULL,           // default security attributes
		OPEN_EXISTING,  // opens existing pipe 
		FILE_FLAG_OVERLAPPED, // default attributes 
		NULL);          // no template file 


	if (pipe == INVALID_HANDLE_VALUE) {
		printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
		exit(1);
	}

	if (!ConnectNamedPipe(pipe, &connectOverlap)) {
		printf("Waiting for pipe to establish connections\n");
		while (HasOverlappedIoCompleted(&connectOverlap)) printf("%u\n", connectOverlap.Internal);
	}

	if (!WriteFile(pipe, &dSend, sizeof(struct pipeData), NULL, &connectOverlap)){
		if (GetLastError() != ERROR_IO_PENDING)
			printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
	}
	//waitingForRequest = false;
	sentResponse = true;

	while (1) {
		if (count < N_HP_VALS){
			//dSend.hp[count].y = 0.5f;
			dSend.hp[count].y = sinf(6.28 * dSend.hp[count].x / 5) / dSend.hp[count].x - .5;
		}
		else{
			for (size_t i = 0; i < N_HP_VALS; i++) dSend.hp[i].y = 0.0f;
			count = 0;
		}
		count++;

		//printf("50th pos: %f\n", dSend.hp[])

		if (sendResponse) {
			//printf("Sending response...\n");
			if (!WriteFile(pipe, &dSend, sizeof(struct pipeData), NULL, &connectOverlap)){
				if (GetLastError() != ERROR_IO_PENDING)
					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
			}

			//printf("Sending response intiated...\n");
			sendResponse = false;
			sentResponse = true;
		}

		if (sentResponse) {
			//printf("Checking if response is done sending... ");
			bool fSuccess = GetOverlappedResult(pipe, &connectOverlap, &nBytesTransferred, FALSE); // See if 
			if (fSuccess) {
				//printf("Sent response process has completed, %u\n", ++count);

				FlushFileBuffers(pipe);

				sendResponse = true;
				sentResponse = false;
			}
			else {
				//printf("Sent response process is incomplete\n");
				if (GetLastError() == ERROR_IO_INCOMPLETE);
				else if (GetLastError() == ERROR_BROKEN_PIPE) {
					FlushFileBuffers(pipe);
					DisconnectNamedPipe(pipe);

					if (!ConnectNamedPipe(pipe, &connectOverlap)) {
						//printf("Waiting for pipe to re-init after disconnect\n");
						while (HasOverlappedIoCompleted(&connectOverlap)) printf("%u\n", connectOverlap.Internal);
						printf("Pipe restored after disconnect\n");
					}

					if (!ReadFile(pipe, data, PIPE_BUFFER_SIZE, NULL, &connectOverlap)){
						if (GetLastError() != ERROR_PIPE_LISTENING);
							printf("ReadFile Error: %u (line: %u)\n", GetLastError(), __LINE__);
					}
				}
				else;
					//printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
			}
		}
	}
}
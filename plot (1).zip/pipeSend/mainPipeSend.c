#include <stdlib.h>
#include <stdio.h>
#include <Windows.h>
#include <time.h>
#include <stdbool.h>


#define PIPE_BUFFER_SIZE	1024

int main(int argc, char *argv[]) {
	size_t nBytesTransferred;
	bool waitingForRequest = false;
	bool sendResponse = false;
	bool sentResponse = false;

	char sendString[] = "Test string";

	unsigned long currentTime;
	char data[2];

	OVERLAPPED connectOverlap;

	connectOverlap.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	connectOverlap.Offset = 0;
	connectOverlap.OffsetHigh = 0;
	fprintf(stdout, "Server started\n");

	//HANDLE pipe = CreateNamedPipe(
	//	"\\\\.\\pipe\\osuPipe",
	//	PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
	//	PIPE_WAIT,
	//	PIPE_UNLIMITED_INSTANCES,
	//	PIPE_BUFFER_SIZE,
	//	PIPE_BUFFER_SIZE,
	//	120 * 1000,
	//	NULL);
	HANDLE pipe = CreateFile(
		"\\\\.\\pipe\\osuPipe",   // pipe name 
		GENERIC_READ |  // read and write access 
		GENERIC_WRITE,
		0,              // no sharing 
		NULL,           // default security attributes
		OPEN_EXISTING,  // opens existing pipe 
		0,              // default attributes 
		NULL);          // no template file 


	if (pipe == INVALID_HANDLE_VALUE) {
		printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
	}

	if (!ConnectNamedPipe(pipe, &connectOverlap)) {
		printf("Waiting for pipe to establish connections\n");
		while (HasOverlappedIoCompleted(&connectOverlap)) printf("%u\n", connectOverlap.Internal);
	}

	WriteFile(pipe, sendString, strlen(sendString), NULL, &connectOverlap);
	waitingForRequest = false;
	sentResponse = true;

	while (1) {
		if (waitingForRequest) {
			printf("Checking if response has been recieved... ");
			bool fSuccess = GetOverlappedResult(pipe, &connectOverlap, &nBytesTransferred, FALSE); // See if 
			if (fSuccess) {
				printf("Response rcvd\n ");
				waitingForRequest = false;
				sendResponse = true;
				sentResponse = false;
			}
			else {
				printf("Response not rcvd yet\n ");
				if (GetLastError() == ERROR_IO_INCOMPLETE);
				else if (GetLastError() == ERROR_BROKEN_PIPE) {
					CloseHandle(pipe);
					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
					DisconnectNamedPipe(pipe);
					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
					// !!!!!!!!!!!!!!!! BUG - Pipe times out if program freezes. Need to somehow check for that
					pipe = CreateNamedPipe(
						"\\\\.\\pipe\\osuPipe",
						PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
						PIPE_WAIT,
						PIPE_UNLIMITED_INSTANCES,
						PIPE_BUFFER_SIZE,
						PIPE_BUFFER_SIZE,
						120,
						NULL);

					if (pipe == INVALID_HANDLE_VALUE) {
						printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
					}

					if (!ConnectNamedPipe(pipe, &connectOverlap)) {
						printf("Waiting for pipe to establish connections\n");
						while (HasOverlappedIoCompleted(&connectOverlap)) printf("%u\n", connectOverlap.Internal);
					}

					ReadFile(pipe, data, PIPE_BUFFER_SIZE, NULL, &connectOverlap);
					waitingForRequest = true;

					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
				}
				else
					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
			}
		}

		if (sendResponse) {
			printf("Sending response...\n");
			WriteFile(pipe, sendString, strlen(sendString), NULL, &connectOverlap);

			waitingForRequest = false;
			sendResponse = false;
			sentResponse = true;
		}

		if (sentResponse) {
			printf("Checking if response is done sending... ");
			bool fSuccess = GetOverlappedResult(pipe, &connectOverlap, &nBytesTransferred, FALSE); // See if 
			if (fSuccess) {
				printf("Sent response process has completed\n");
				ReadFile(pipe, data, PIPE_BUFFER_SIZE, NULL, &connectOverlap);
				waitingForRequest = true;
				sendResponse = false;
				sentResponse = false;
			}
			else {
				printf("Sent response process is incomplete\n");
				if (GetLastError() == ERROR_IO_INCOMPLETE);
				else if (GetLastError() == ERROR_BROKEN_PIPE) {
					CloseHandle(pipe);
					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
					DisconnectNamedPipe(pipe);
					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
					// !!!!!!!!!!!!!!!! BUG - Pipe times out if program freezes. Need to somehow check for that
					pipe = CreateNamedPipe(
						"\\\\.\\pipe\\osuPipe",
						PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
						PIPE_WAIT,
						PIPE_UNLIMITED_INSTANCES,
						PIPE_BUFFER_SIZE,
						PIPE_BUFFER_SIZE,
						120,
						NULL);

					if (pipe == INVALID_HANDLE_VALUE) {
						printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
					}

					if (!ConnectNamedPipe(pipe, &connectOverlap)) {
						printf("Waiting for pipe to establish connections\n");
						while (HasOverlappedIoCompleted(&connectOverlap)) printf("%u\n", connectOverlap.Internal);
					}

					ReadFile(pipe, data, PIPE_BUFFER_SIZE, NULL, &connectOverlap);
					waitingForRequest = true;

					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
				}
				else
					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
			}
		}
	}
}
#define _CRT_SECURE_NO_WARNINGS
#define TRACE_ON

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <Windows.h>
#include "window.h"


#ifndef TRACE_ON
#define TRACE 0
#else
#define TRACE 1
#endif

#define AXIS_X_MARGIN_LEFT      30
#define AXIS_X_MARGIN_RIGHT     10
#define AXIS_Y_MARGIN_TOP       10
#define AXIS_Y_MARGIN_BOTTOM    30

#define PIPE_BUFFER_SIZE	1024

static const struct
{
	float x, y;
	float r, g, b;
} vertices[3] =
{
	{ -0.6f, -0.4f, 1.f, 0.f, 0.f },
	{ 0.6f, -0.4f, 0.f, 1.f, 0.f },
	{ 0.f,  0.6f, 0.f, 0.f, 1.f }
};

void drawIMgui(int width, int height, const char* displayText) {
	// GUI ================================================================
	ImGui_ImplGlfwGL3_NewFrame();

	ImGuiWindowFlags blankFlag = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize;

	igPushStyleVar(ImGuiStyleVar_WindowRounding, 0);
	struct ImVec4 colWindowBG = { 0.9f, 0.9f, 0.9f, 1.0f };
	struct ImVec4 colText = { 0.1f, 0.1f, 0.1f, 1.0f };

	igPushStyleColor(ImGuiCol_WindowBg, colWindowBG);
	igPushStyleColor(ImGuiCol_Text, colText);
	igBegin("Text Window", false, blankFlag);
	{
		const struct ImVec2 igOriginPoint = { 0, 0 };
		const struct ImVec2 igTextWindowSize = { width, height / 5 };

		igSetWindowPos(igOriginPoint, true);
		igSetWindowSize(igTextWindowSize, true);
		//igSetWindowSize({ (float)width, (float)height }, true);
		igText("Testing, 1-2-3");
		igText("Testing, Lorem ipsum dolor sit blah blah blah");
		igText(displayText);
	}


	const struct ImVec2 igGraphWindowOriginPoint = { 0, height / 5 };
	const struct ImVec2 igGraphWindowSize = { width, height * 4 / 5 };

	struct ImVec4 colAxis = { 0.4f, 0.4f, 0.4f, 1.0f };
	struct ImVec2 vertsAxis[] = {
		{ igGraphWindowOriginPoint.x + AXIS_X_MARGIN_LEFT, igGraphWindowOriginPoint.y + AXIS_Y_MARGIN_TOP },
		{ igGraphWindowOriginPoint.x + AXIS_X_MARGIN_LEFT, igGraphWindowOriginPoint.y + igGraphWindowSize.y - AXIS_Y_MARGIN_BOTTOM },
		{ igGraphWindowSize.x - AXIS_X_MARGIN_RIGHT, igGraphWindowOriginPoint.y + igGraphWindowSize.y - AXIS_Y_MARGIN_BOTTOM } };


	colWindowBG.x = 0.1f;
	colWindowBG.y = 0.1f;
	colWindowBG.z = 0.1f;
	igPushStyleColor(ImGuiCol_WindowBg, colWindowBG);
	igBegin("Graph Window", false, blankFlag);
	{

		igSetWindowPos(igGraphWindowOriginPoint, true);
		igSetWindowSize(igGraphWindowSize, true);

		struct ImDrawList* drawlist = igGetWindowDrawList();
		ImDrawList_AddLine(drawlist, vertsAxis[0], vertsAxis[1], igGetColorU32Vec(&colAxis), 2);
		ImDrawList_AddLine(drawlist, vertsAxis[1], vertsAxis[2], igGetColorU32Vec(&colAxis), 2);

	}
	igEnd();
}



int main() {
	GLFWwindow* window = NULL;
	int width = 0, height = 0;

	GLuint vertex_shader, fragment_shader, program;
	GLint attribute_coord2d, uniform_offset_x, uniform_scale_x, uniform_cutoff;
	GLuint vao; GLuint vbo;
	GLuint tex, fbo;
	struct ImVec4 clear_color = { 0.05f, 0.05f, 0.05f, 1.00f };


	OVERLAPPED connectOverlap;
	size_t nBytesTransferred;
	bool waitingForRequest = true;
	bool sendResponse = false;
	bool sentResponse = false;
	char data[PIPE_BUFFER_SIZE];
	char* displayText = (char*)calloc(1, sizeof(char));

	// Timer
	double timeStarted = glfwGetTime();

	// List of points to plot
	struct point graph[2000];
	for (int i = 0; i < 2000; i++) {
		float x = (i - 1000.0f) / 100.0f;
		graph[i].x = x;
		//graph[i].y = sinf(6.28f * x*(x + 5.5*x)*(x / 6 - 20.0) * (1.5 / 20.0f)) / x;
		graph[i].y = sinf(6.28 * x / 5)/x - .5;
	}

	// Initialize GLFW
	initGLFW(&window, &width, &height);

	vertex_shader = glCreateShader(GL_VERTEX_SHADER);
	fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);
	program = glCreateProgram();
	compileShaders(vertex_shader, fragment_shader, program);

	// Get shader internal addresses
	attribute_coord2d = glGetAttribLocation(program, "coord2d");
	uniform_offset_x = glGetUniformLocation(program, "offset_x");
	uniform_scale_x = glGetUniformLocation(program, "scale_x");
	uniform_cutoff = glGetUniformLocation(program, "cutoff");

	// Gen and fill VBO to hold vertices
	glGenBuffers(1, &vbo);
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, 2000 * 2 * sizeof(float), graph, GL_STATIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	// Generate VAO
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	// Enable blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// Generate fbo and tex for MSAA
	glGenTextures(1, &tex);
	glGenFramebuffers(1, &fbo);

	// Pipe setup
	connectOverlap.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	connectOverlap.Offset = 0;
	connectOverlap.OffsetHigh = 0;
	fprintf(stdout, "Server started\n");

	HANDLE pipe = CreateNamedPipe(
		"\\\\.\\pipe\\osuPipe",
		PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
		PIPE_WAIT,
		PIPE_UNLIMITED_INSTANCES,
		PIPE_BUFFER_SIZE,
		PIPE_BUFFER_SIZE,
		120 * 1000,
		NULL);

	if (pipe == INVALID_HANDLE_VALUE) {
		printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
	}

	if (!ConnectNamedPipe(pipe, &connectOverlap)) {
		printf("Waiting for pipe to establish connections\n");
		while (HasOverlappedIoCompleted(&connectOverlap)) printf("%u\n", connectOverlap.Internal);
	}
	ReadFile(pipe, data, PIPE_BUFFER_SIZE, NULL, &connectOverlap);
	waitingForRequest = true;


	//if (TRACE) printf("line:%u: GL Error code: %u\n", __LINE__, glGetError());

	while (!glfwWindowShouldClose(window)) {
		glfwPollEvents();

		if (waitingForRequest) {
			bool fSuccess = GetOverlappedResult(pipe, &connectOverlap, &nBytesTransferred, FALSE); // See if 
			if (fSuccess) {
				free(displayText);
				displayText = (char*)calloc(strlen("Recieved text: ") + nBytesTransferred + 1, sizeof(char));
				strcat(displayText, "Recieved text: ");
				memcpy(displayText + strlen("Recieved text: "), data, nBytesTransferred);

				waitingForRequest = false;
				sendResponse = true;
				sentResponse = false;
			}
			else {
				if (GetLastError() == ERROR_IO_INCOMPLETE);
				else if (GetLastError() == ERROR_BROKEN_PIPE) {
					CloseHandle(pipe);
					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
					DisconnectNamedPipe(pipe);
					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
					// !!!!!!!!!!!!!!!! BUG - Pipe times out if program freezes. Need to somehow check for that
					pipe = CreateNamedPipe(
						"\\\\.\\pipe\\osuPipe",
						PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
						PIPE_WAIT,
						PIPE_UNLIMITED_INSTANCES,
						PIPE_BUFFER_SIZE,
						PIPE_BUFFER_SIZE,
						120,
						NULL);

					if (pipe == INVALID_HANDLE_VALUE) {
						printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
					}

					if (!ConnectNamedPipe(pipe, &connectOverlap)) {
						printf("Waiting for pipe to establish connections\n");
						while (HasOverlappedIoCompleted(&connectOverlap)) printf("%u\n", connectOverlap.Internal);
					}

					ReadFile(pipe, data, PIPE_BUFFER_SIZE, NULL, &connectOverlap);
					waitingForRequest = true;

					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
				}
				else
					printf("Error: %u (line: %u)\n", GetLastError(), __LINE__);
			}
		}

		if (sendResponse) {
			unsigned int currentTime = (unsigned long)time(NULL);
			WriteFile(pipe, &currentTime, sizeof(unsigned long), NULL, &connectOverlap);
			
			waitingForRequest = false;
			sendResponse = false;
			sentResponse = true;
		}

		if (sentResponse) {
			bool fSuccess = GetOverlappedResult(pipe, &connectOverlap, &nBytesTransferred, FALSE); // See if 
			if (fSuccess) {
				ReadFile(pipe, data, PIPE_BUFFER_SIZE, NULL, &connectOverlap);
				waitingForRequest = true;
				sendResponse = false;
				sentResponse = false;
			}
		}

		printf("Error: %u\n", GetLastError());

		// Set up viewport
		int width, height;
		glfwGetFramebufferSize(window, &width, &height);

		// Lay out UI
		drawIMgui(width, height, displayText);

		// Render everything to the framebuffer
		// Bind and set up framebuffers for MSAA
		bindFBO(tex, fbo, width, height);

		// Set up viewport for rendering plot
		struct ImVec4 viewportBounds = {
			AXIS_X_MARGIN_LEFT + 2,
			AXIS_Y_MARGIN_BOTTOM + 2,
			width - AXIS_X_MARGIN_RIGHT - AXIS_X_MARGIN_LEFT,
			(height * 4 / 5) - AXIS_Y_MARGIN_TOP - AXIS_Y_MARGIN_BOTTOM
		};
		glViewport(viewportBounds.x, viewportBounds.y, viewportBounds.z, viewportBounds.w);

		// Clear screen
		glClearColor(clear_color.x, clear_color.y, clear_color.z, clear_color.w);
		glClear(GL_COLOR_BUFFER_BIT);

		// Render IMgui
		igRender();

		// Render OpenGL
		glUseProgram(program);

		// Set shader uniforms
		glUniform1f(uniform_offset_x, 0);
		glUniform1f(uniform_scale_x, 0.1f);
		glUniform1f(uniform_cutoff, 2.0*((glfwGetTime() / 3) - (int)(glfwGetTime() / 3) - 0.5f));
		//printf("Time: %f\n", glfwGetTime() - (int)glfwGetTime());

		// Activate VBO for rendering
		glBindBuffer(GL_ARRAY_BUFFER, vbo);

		// Define VBO attributes
		glEnableVertexAttribArray(attribute_coord2d);
		glVertexAttribPointer(
			attribute_coord2d,   // attribute
			2,                   // number of elements per vertex, here (x,y)
			GL_FLOAT,            // the type of each element
			GL_FALSE,            // take our values as-is
			0,                   // no space between values
			0                    // use the vertex buffer object
		);

		// Draw points
		glLineWidth(1.25);
		glDrawArrays(GL_LINE_STRIP, 0, 2000);

		// Unbind framebuffer
		renderFBO(tex, width, height);

		// Unbind program
		glUseProgram(0);
		// /GUI ===============================================================

		glfwSwapBuffers(window);
	}

	glfwDestroyWindow(window);
	glfwTerminate();
	return 0;
}